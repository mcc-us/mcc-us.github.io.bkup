## Chapter 1

Introduction: Accounting System
Introduction

Who Should Use this Guide?

This Bookkeeping Guide is for anyone who performs bookkeeping or related tasks using QuickBooks Online includes:

1. Bookkeeping students
2. Bookkeeping employees
3. Bookkeeping business owners
4. Small business owners

**Guide Objectives: Efficiently, accurately, and productively perform bookkeeping**

1. Provide timely, relevant, and reliable financial information
2. Increase financial position, profit, and cash flow


Understand how accounting process automation has transformed bookkeeping

This Guide presents Accounting Analytics Accounting System's bookkeeping process using QuickBooks Online. This bookkeeping process enables bookkeepers to achieve these four objectives.

Business Success

There are three things that communicate and determine business success:

1. Financial Position
2. Profit
3. Cash Flow

You measure your company’s financial position by analyzing your company’s statement of financial position or **balance sheet**.  A balance sheet is a financial report that reports a company’s assets (resources), liabilities (obligations), and owner's equity (ownership) as of a specific date such as the last day of a month, quarter, or year. You increase your financial position by increasing assets and decreasing liabilities.

You measure your company’s profit by analyzing your company’s income or profit and loss statement. A profit and loss statement is a financial report that reports a company’s income, expenses, and profit or loss over a period of time such as a month, quarter, or year. You increase profit by increasing income and decreasing expenses.

You measure your company’s cash flow by analyzing your company’s statement of cash flows or cash flow statement. A statement of cash flows is a financial report that reports a company’s sources and uses of cash and net cash increase or decreases over a period of time such as a month, quarter, or year. You increase cash by increasing sources of cash and decreasing uses of cash.

Each of these financial statements, along with other financial reports, is used in evaluating a company’s financial position, profit, and cash flow and determining the company’s financial health. Owners use that information to increase their company’s financial position, profit, and cash flow

Timely, relevant, and Reliable Financial Information

Business owners build successful businesses by making good business decisions and good decisions are made when owners make those decisions based on timely, relevant, and reliable financial information.

Timely financial information refers to the need for financial information to be presented to the users of the financial information in time to enable them to make informed decisions.

Relevant financial information refers to the need for financial information to be capable of affecting the decisions of the users of financial information. The information should be useful and not useless.

Reliable financial information refers to whether the financial information can be verified and usedconsistently by the users of the
financial information with the same results. Reliability refers to the trustworthiness of financial information.

Accounting Analytics Accounting System

An accounting system is a set of tools, processes, methods, policies, procedures, and controls that gather, record, classify, analyze, summarize, interpret, and communicate business information.

The purpose of accounting is to communicate a business's financial position, profit, and cash flow. Our Accounting System communicates and increases your financial position, profit, and cash flow.

When we developed our Accounting System, we analyzed every component of an accounting system. We adapted leading tools and technology and developed processes, methods, policies, procedures, and controls to efficiently and productively increase a company's financial position, profit, and cash flow.

Our Accounting System includes:

An eCommerce website

Bookkeeping

Payroll

Accounting

Reports

Business performance analysis

Cash flow management


Tax planning and preparation

eCommerce Website

eCommerce is a general term that includes virtually any transaction that takes place on the Internet.

An eCommerce website is a website with eCommerce functionality that allows customers or clients to purchase and pay for your products or services via the Internet.

Your website should increase sales and receipts. It should also integrate with your accounting system so you can gather, record, and classify sales and receipt transactions and your accountant can analyze, summarize, interpret, and communicate sales and receipt information.

Our eCommerce websites increase sales and receipts and integrate with your accounting system.

Bookkeeping

Bookkeeping is the day-to-day gathering, recording, and classifying of financial transactions, such as sales and receipts and purchases and payments, and is the foundation of your accounting system.

Bookkeeping is critical to cash flow because bookkeeping controls the timing of receipts and payments. Effective cash flow management requires that receipts be received as soon as possible, and payments are paid as late as possible, but on time to maintain vendor relations. Bookkeeping also determines whether your business information is timely, relevant, and reliable.

Our bookkeeping process increases your financial position, profit, and cash flow and is the foundation for timely, relevant, and reliable business information.

Payroll

Payroll and employee benefits are your highest business expense and should receive constant attention.

Effective cash flow management requires payroll, payroll taxes, and employee benefits to be paid as late as possible, but on time to avoid penalties and interest. Payroll and employee benefits expenses should be reviewed and negotiated at least annually.

Our payroll process ensures your payroll, payroll taxes, and employee benefits are paid as late as possible, but on time.

Accounting

Accounting involves analyzing, summarizing, interpreting, and communicating business information.
Business information is communicated through financial and management reports and business performance analysis.

Business decisions are based on financial and management reports and business performance analysis.

Business information must be timely, relevant, and reliable since business decisions can make or break business success.

Our accounting assures the owner that their business information is timely, relevant, and reliable.

Reports

Bill Gates stated, 
> *“The term, information at your fingertips, is to remind people what a broad role the personal computer will be playing. It is not a computation device; it is not a word processing or a spreadsheet device. It is a window into the world ofm information.”*

Financial and management reports are the window into the world of business information.

At the end of each day, week, month, quarter, and year; our Accounting System provides financial and management reports that keep owners informed of their financial position, profit, and cash flow.

These reports communicate daily, weekly, monthly, quarterly, and yearly business performance and help owners make better business decisions.

Business Performance Analysis

It has been said, *“You must know where you are to decide where you are going.”*

Our business performance analysis analyzes your company's **key performance indicators** (KPIs). KPIs are the elements of a business performance plan that express what the owner wants to achieve and when they want to achieve it. They are the quantifiable, outcome-based indicators used to measure if the owner is on track to meet their business performance goals.

The owner uses the analysis to know their company’s performance and make better business decisions.

Our business performance analysis helps the owner know their company’s financial position, profit, and cash flow; make better business decisions, and increase their financial position, profit, and cash flow.

Cash Flow Management

As any business owner knows, cash is king, and it is no coincidence that "Cash" is the first line item on your balance sheet. A classified balance sheet is presented in the order of liquidity or in the order of the amount of time it takes an asset or liability to convert into cash.

The purpose of a business is to generate cash and what you do with that cash is your business

Our Accounting System is designed with cash flow tools, technology, processes, methods, policies, procedures, and controls to increase your company's financial position, profit, and cash flow.

Tax Planning and Preparation

Tax planning is a plan, from a tax perspective, to reduce tax liability and prepare for retirement.
Tax preparation is preparing the tax return after the tax year is over when most opportunities to reduce tax liability are gone.

Our tax planning reduces the owner's tax liability and prepares him or her for retirement.

Implementing the Accounting System

A large corporation's accounting system is developed and maintained by the CFO (Chief Financial Officer), managed by a Controller, and performed by Senior and Junior Accountants and administrative assistants.

An accounting firm's accounting system is developed and maintained by the Partner(s), managed by a Manager, and performed by Senior and Junior Accountants.

A small business's accounting system is developed and maintained by the company’s accounting firm, managed by the firm's Manager, and performed by the firm's Senior and Junior Accountants or the business owner's bookkeeper.

Who Should Perform the Bookkeeping?

There are three people who can perform the bookkeeping for a small business:

1. Owner
2. Employee
3. Independent contractor (bookkeeper or accountant)

Note: Accountants are defined as individuals who possess accounting degrees. Accountants can perform bookkeeping but should not or prefer not to. Accountants generally earn a higher income performing accounting work or services and they obtained their degree to perform accounting, not bookkeeping.

A small business owner should not perform their own bookkeeping. They make better use of their time working on their business and not working in their business. The owner should delegate their bookkeeping to a trained, certified, and experienced employee or independent contractor bookkeeper.

To determine whether to delegate their bookkeeping to an employee, bookkeeper or accountant, a business owner should perform a cost-benefit analysis. A cost-benefit analysis is a process a business owner uses to analyze decisions. The owner sums the benefits of a situation or action and then subtracts the costs associated with taking that action

If the business owner chooses to have an employee perform their bookkeeping, the owner shouldensure the employee is trained, certified, experienced, supported, and supervised.

Intuit has a reputation for developing DIY (Do-it-yourself) applications such as Mint for personal budgeting, QuickBooks for bookkeeping, and TurboTax for tax preparation. Therefore, many small business owners believe Intuit developed QuickBooks to replace their accountants. Thus, many QuickBooks Users do not have bookkeeping training, certification, experience, support, and supervision.

Intuit developed QuickBooks to enable small businesses to perform their bookkeeping with assistance from their accountants. This is the relationship small business owners and accountants should develop.

Many small businesses have the following responsibilities

Bookkeeping

- Payroll
- Merchant Account
- Accounting
- Business Performance Analysis
- Tax Preparation

Intuit is QuickBooks Online Ecosystem provides the following tools to assist small business owners and accountants in completing
these responsibilities:

Bookkeeping — QuickBooks Online,

- Payroll — QuickBooks Online Payroll
- Merchant Account — QuickBooks Payments
- Accounting — QuickBooks Online Accountant
- Business Performance Analysis — Fathom (QuickBooks Online third-party app)

### Tax Preparation — Intuit ProConnect Tax Online

The person responsible for completing these responsibilities should be:

- Bookkeeping — small business employee or independent contractor bookkeeper
- Payroll — small business employee or independent contractor bookkeeper
- Merchant Account — small business employee or independent contractor bookkeeper
- Accounting — accountant

### Business Performance Analysis — accountant

Tax Preparation — accountant or tax preparer

Accounting Analytics was developed based on this model. Therefore, we provide the following services:

eCommerce website setup, hosting, maintenance, training, and support

- Bookkeeping setup, training, certification, support, and supervision
- Payroll setup, training, certification, support, and supervision
- QuickBooks Online Ecosystem setup, training, certification, support, and supervision
- Accounting
- Business performance analysis
- Tax planning and preparation

## Chapter Overviews

This Guide presents the bookkeeping process of our Accounting System

## Chapter 2 - Bookkeeper Tools

This chapter presents the bookkeeping tools utilized in our Accounting System.
The chapter addresses Support tools, Bookkeeping tools, Payroll tools, and Accounting tools.

Accounting Analytics utilizes the leading support, bookkeeping, payroll, and accounting tools. We utilize hardware and
applications that maximize efficiency and productivity.

## Chapter 3 - Setting Up Your Bookkeeping

This chapter presents the information needed and the steps necessary to properly set up your bookkeeping.

## Chapter 4 - Processing Bank and Credit Card Accounts

Processing bank and credit card accounts are critical activity for small businesses. Not only must you follow practices that protect
the company's cash from misuse, but you must process it accurately to productively manage the company’s cash flow and
maintain good financial institution relations.

This chapter provides you with step-by-step guidance for processing bank and credit card accounts.

The guidance in the chapter is useful to bookkeepers as well as personnel involved in bank and credit card account activities. The
chapter helps bank and credit card account personnel fine-tune their processing activities and provides newly hired or cross-
trained employees with a foundation for processing bank and credit card accounts.

## Chapter 5 - Processing Sales and Receipts

Processing sales and receipts are critical activities of small businesses. Not only must you followpractices that increase cash flow
and protect the company’s cash from misuse, but you must process it accurately to productively manage the company's cash
flow and maintain good customer relations.

This chapter provides bookkeepers with step-by-step guidance for processing sale and receipt transactions.

The guidance in the chapter is useful to bookkeepers as well as personnel involved in sales and receipts activities. The chapter
helps sales and receipts personnel fine-tune their processing activities and provides newly hired or cross-trained employees with a
foundation for processing sales and receipts.

## Chapter 6 - Processing Purchases and Payments

Processing purchases and payments are critical activities of small businesses. Not only must you follow practices that increase
cash flow and protect the company’s cash from misuse, but you must process it accurately to productively manage the
company's cash flow and maintain good vendor relations

This chapter provides you with step-by-step guidance for processing purchase and payment transactions.

The guidance in the chapter is useful to bookkeepers as well as personnel involved in purchases and payments activities. The
chapter helps purchases and payments personnel fine-tune their processing activities and provides newly hired or cross-trained
employees with a foundation for processing purchases and payments.

## Chapter 7 - Communicating Business Performance

Management is informed of their company’s business performance by analyzing QuickBooks reports. QuickBooks reports organize
and communicate timely, relevant, and reliable financial information to company management to assist them in making better
business decisions.

This chapter provides step-by-step guidance for organizing and communicating business performance.

The guidance in the chapter is useful to bookkeepers as well as personnel involved in report activities.

Overview of the Accounting System

An understanding of the accounting system is helpful to anyone performing an accounting process. It is especially important to
anyone who performs several accounting processes. When they understand the "big picture”, they realize how important their
work is and how vital it is to the accounting system.

This overview provides an outline of a small business accounting system.

The overview includes:

- Types of Financial Records. This section briefly discusses the five types of financial records(source documents, summary
journals, subsidiary ledgers, general ledger, and financial reports) used in most small businesses

- Primary Accounting Processes. This section addresses four of the six accounting processes found in most small businesses:
sales, accounts receivable, and cash receipts; purchasingaccounts payable, and cash disbursements; payroll; inventories and
costs of sales; fixed assets and depreciation; and general ledger and financial reports

### Basic Internal Accounting Controls. This section provides a brief overview of the basic smallbusiness internal accounting
controls

Note: QuickBooks terminology is used to better understand the accounting system using QuickBooks.

Types of Financial Records

Each company’s accounting system is responsible for distilling the hundreds or thousands of monthly transactions into a
manageable format, i.e., the month-end general ledger and financial statements. The monthly financial transactions in most small
businesses start with one or more source documents, such as invoices, cash receipts, and time sheets, which are summarized
throughout the month and posted to specified general ledger accounts. The ending monthly general ledger balances are then
used to generate the company's financial reports.

The image below presents a pyramid to show how the various source documents and other financial records are processed
throughout each period to produce the company’s month-end financial information. The following paragraphs briefly discuss the
types of financial records shown in the image below and the bookkeeper and accountants involvement with the records.

Source Documents

Each accounting transaction begins with some type of source document, which differs depending on the type of transaction. The
source documents that account for most financial transactions include:

Sales - Invoices and Sales Receipts are the primary source documents for customer salestransactions

- Cash receipts - Receive Payments and Bank Deposits are the primary source documents for cash received from customers on
sales on account. For companies that do not extend credit to customers, the Sales Receipt source document also serves as
the sales document

- Purchases - Vendor invoices (Bills) are the primary source document for vendor purchases on account
- Cash disbursements — Company check and credit card payments accompanied by approved vendor invoices (Bills) and
receipts supporting the purchase are the primary supporting documents for cash disbursements

- Payroll - Single or Weekly Timesheets showing time worked by employees are the primary supporting documents for recording
payroll costs. Paychecks and direct deposits (ACH or eCheck) are the primary documents supporting the payment of payroll
costs

Whenever possible, appropriate controls (such as using pre-numbered source documents) should exist to help ensure that all
transactions are captured and recorded

Journal

Each transaction is recorded from its source document and summarized in a Transaction Journal. The Transaction Journal lists the
date, transaction type, number, name, memo/description, accounts, debit, credit, and amount. The Transaction Journal is then
posted to the general journal.

Note: In QuickBooks, you can view Transaction Journals in a Journal Report for a selected period of time.

To view the Journal Report:

1. Select Reports from the left menu
2. Scroll down to the For My Accountant report section

3. Select Journal

Transaction Journals not only provide a trail showing amounts posted to the general ledger, but they also show the detailed
components making up each general ledger posting. This detail makes it easier for accounting personnel to locate original source
documents when questions arise at a later date.

Subsidiary Ledgers

As the system posts Transaction Journal amounts to the general ledger, the system also generates subsidiary ledgers for selected
balance sheet accounts, such as accounts receivable and accounts payable. These subsidiary ledgers show the composition of
ending general ledger account balances.

1. Accounts receivable — The accounts receivable subsidiary ledger (Accounts Receivable Aging Detail or Summary reports)
shows the date, transaction type, number, customer, due date, amount, and open balance owed by the customer. Amounts
owed are divided by current, 1-30 days past due, 31-60 days past due, and 61-90 days past due

2. Accounts payable — The accounts payable subsidiary ledger (Accounts Payable Aging Detail or Summary reports) shows the
date, transaction type, number, vendor, due date, amount, and open balance owed by the vendor. Amounts owed are divided
by current, 1-30 days past due, 31-60 days past due, and 61-90 days past due

Subsidiary ledgers are key financial records used for managing each of these balance sheet accounts on a day-to-day basis. Thus,
it is crucial that bookkeepers record individual transactions accurately and on a timely basis to ensure that the subsidiary ledgers
remain useful and in agreement with the related general ledger balances.

General Ledger

Transaction Journals record transaction amounts by general ledger account so the system can post to and update the general
ledger. Accountants also update the general ledger by preparing manual journal entries for transactions, such as depreciation or
period-end accruals, that are not accumulated and posted automatically through Transaction Journals.

The general ledger lists the period-beginning and period-end balance for each general ledger account. It also lists each
Transaction Journal from the period-beginning to the period-end activity posted to each general ledger account.

Note: In QuickBooks, you can view the general ledger in a General Ledger Report for a selected period of time.

To view the General Ledger Report:

1. Select Reports from the left menu
2. Scroll down to the For My Accountant report section

3. Select General Ledger

General ledger accounts are comprised of assets, liabilities, and equity accounts (balance sheetaccounts) and income and
expense accounts (income statements or profit and loss accounts). For the general ledger to be "in balance,” the period's total
debits must equal the total credits. In addition, the income-less expenses must equal the net income or profit added to the
retained earnings account

Financial Reports

Financial reports simply represent a summarization and grouping of period-end general ledger amounts into designated financial
statement captions such as cash, accounts receivable, accounts payable, income, cost of sales, expenses, and net income or
profit. QuickBooks reports define which general ledger accounts are grouped into which financial report captions.

Common financial reports include a statement of financial condition (balance sheet), income statement (profit and loss), and
statement of cash flows (cash flow statement). The balance sheet and profit and loss are taken directly from the corresponding
general ledger accounts. The cash flow statement is derived from the balance sheet and profit and loss statements.

Primary Accounting Processes

Accounting activities generally fall into one of several natural accounting processes or cycles. In the Accounting Analytics
Accounting System, the bookkeeper is responsible for the first three processes and the accountant is responsible for the last three
processes. Whether the bookkeeper performs a process or not, it is important they have a basic understanding of the steps in
each process.

The primary accounting system processes include:

Sales, accounts receivable, and cash receipts
. Purchasing, accounts payable, and cash disbursements

. Payroll

1
2,
3
4. Inventories and costs of sales
5. Fixed assets and depreciation
6.

. General ledger and financial reports

The six processes are briefly discussed below.

Note: Although each step in each primary process is presented to enable the bookkeeper to better understand the process,
QuickBooks is programmed to automatically process certain steps

Sales, Accounts Receivable, and Cash Receipts

This process or cycle consists of selling products or services and receiving payment from customers. The bookkeeper’ role in this
process generally consists of the following:

Account maintenance - Setting up new customers and updating/deactivating customers

- Data entry (invoices) — Recording Invoices (and Credit Memos if any) into the accounting system to produce the Invoice
Transaction Journals

- General ledger posting (invoices) — Posting the Invoice Transaction Journals to the Accounts Receivable Aging and applicable
general ledger accounts (debit to accounts receivable and credit to sales)

- Data entry (customer payments) — Creating Receive Payments against the open Invoices to produce the Receive Payment
Transaction Journals

- General ledger posting (payments) — Posting the Receive Payment Transaction Journals to the Accounts Receivable Aging
and applicable general ledger accounts (debit cash and creditaccounts receivable)

- Reconciliation — Keeping the Accounts Receivable Aging in balance with the ending general ledger balance
A crucial part of this process is ensuring that invoices, payments, and any adjustments are recorded accurately and on a timely
basis. If the transactions are recorded inaccurately or timing is delayed, the Accounts Receivable Aging balance will become

unreliable for managing receivables, customer complaints will become commonplace, and financial report accuracy could
diminish.

## Chapter 5: Processing Sales and Receipts, provides an in-depth discussion of this process.

Purchasing, Accounts Payable, and Cash Disbursements

This process or cycle consists of the purchase of products or services and the subsequent payment for those products or services.
The bookkeeper’ role in this process generally consists of the following

- Account maintenance — Setting up new vendor accounts and updating/deactivating vendors
  
- Categorizing — Ensuring that vendor invoices (Bills) are coded with the appropriate general ledger accounts based on the chart of accounts. Proper account categorization requires bookkeeping personnel to have a strong understanding of the company’s chart of accounts

- Data entry (vendor invoices) — Recording the Bills (including Vendor Credits if any) into the accounting system to produce the Bill Transaction Journals

- General ledger posting (vendor invoices) — Posting the Bill Transaction Journals to the Accounts Payable Aging and applicable general ledger accounts. Such as recording a debit to the appropriate asset or expense accounts and a credit to accounts payable

- Check preparation — Selecting invoices to pay (Pay Bills) and preparing checks for paying vendor purchases to produce the Check Printed Transaction Journals

- General ledger posting (checks) — Posting the Check Printed Transaction Journals to the Accounts Payable Aging and the general ledger accounts (debit to accounts payable and credit to cash)

- Reconciliation — Keeping the Accounts Payable Aging in balance with the ending general ledger balance A crucial part of this process is ensuring that vendor invoices, payments, and any adjustments are recorded accurately and on a timely basis. If the transactions are recorded inaccurately or timing is delayed, the Accounts Payable Aging balance will become unreliable for managing payables, vendor relations will suffer, and financial report accuracy could diminish.

## Chapter 6: Processing Purchases and Payments, provides an in-depth discussion of this process

Payroll

The payroll process or cycle consists of processing payrolls and remitting amounts due to employees, the government, and others
(health insurers, retirement plan trustees, etc.). The bookkeeper's role in this process generally consists of the following:

Account maintenance — Setting up new employees, updating/terminating employees, changing pay rates and tax rates,
revising employee withholding amounts, etc

- Timesheets processing — Ensuring time is entered and completed at the payroll cutoff date

- Data entry — Employees recording time, including hours worked, time off, and overtime hoursinto the accounting system to produce the Payroll Check Transactions Journals

- General ledger posting (payroll checks) — Posting the Payroll Check Transaction Journals to the general ledger. For example, debit wages expense and credit liability accounts for net payroll (accrued wages) and payroll taxes

- Check preparation — Preparing and distributing employee Payroll Checks to the checking account register

- General ledger posting — Posting the checking account register to the general ledger accountsFor example, debit liability accounts (accrued wages and payroll taxes) and credit checkingaccount

- Tax reports preparation and deposits — Preparing payroll tax reports and making required taxdeposits to state and federal agencies

A crucial part of this process is ensuring that employee time, paychecks, and tax payments are recorded accurately and distributed on a timely basis. If the transactions are recorded inaccurately or timing is delayed, the payroll balances will become unreliable for managing payroll, employee complaints will become commonplace, tax penalties may occur, and financial report accuracy could diminish.

The Accounting Analytics Bookkeeping with QuickBooks Online guide provides an in-depth discussion of this process.

General Ledger and Financial Reports

The general ledger process consists of posting the period's transactions to the general ledger and preparing financial reports. The accountants role in this process generally includes:

- Posting Transaction Journals — Transaction Journals are typically posted by the system throughout the month as transactions are processed

- Preparing manual Journal entries — Recording and posting Journal Entries varies depending on the type of Journal Entry. The Journal Entries may be either recurring Journal Entries that must be made each month or adjusting Journal Entries that are made as needed to correct any general ledger account balances

- Generating the trial balance — The trial balance is simply a listing of all general ledger accounts in order of the financial statement report accounts (balance sheet and profit and loss statements). Accounting personnel generate the general ledger trial balance to ensure total debits equal total credits and review the accounts for correct balances

- Verifying account balances with supporting work papers or documents is vital to ensuring the accuracy of the general ledger —
Such as comparing the bank, accounts receivable, accounts payable, and credit card account balances with the bank
reconciliation, Accounting Receivable Aging, Accounts Payable Aging, and credit card reconciliation. Accounting persons
should investigate out-of-balance situations and prepare adjusting journal entries when needed

- Closing out — Closing out the general ledger involves making an entry to zero out all profit and loss accounts for the period
(month, quarter, or year) and posting the offsetting entry to the balance sheet’ retained earnings account. After making this
entry, the balance sheet should be in balance (assets should equal liabilities plus equity)

- Producing the financial statement reports — Producing the financial statement reports is done after the general ledger has
been prepared and is in balance. Computer-generated financial statement reports typically include a balance sheet, profit and
loss statement, and cash flow statement

The accountants main concern in preparing the general ledger and financial statement reports is ensuring that all entries
(Transaction Journals, recurring and adjusting entries) have been accurately posted. A careful review of the trial balance and
general ledger and a comparison to supporting work papers will often reveal additional adjusting journal entries that are needed
to correct errors.

Basic Internal Accounting Controls

Although bookkeepers are not generally involved with ensuring appropriate internal accounting controls, a basic understanding of
accounting controls is helpful in carrying out day-to-day tasks. This knowledge also helps bookkeepers better understand why
they are asked to perform certain procedures.

This section discusses the following general categories of internal accounting controls:

Segregation of duties
- Restricted access
- Document controls

- Processing controls

### Reconciliation controls

Segregation of Duties

Segregation of duties involves allocating bookkeeping tasks among personnel so one individual does not have the ability to make
an accounting error (either intentionally or unintentionally) or cover one up.

The principle of segregation of duties implies that the person with physical access to cash or other moveable assets (investments
or inventory) should not also be involved with the related record keeping. For example, the person opening the mail and depositing
customer payments should not also be responsible for maintaining the Accounts Receivable Aging. In addition, the person
responsible for writing checks should not also have responsibility for maintaining the Accounts Payable Aging.

Whenever possible, bank accounts should be reconciled by someone with no other cash receipt or disbursement functions.

Unfortunately, the limited number of bookkeeping personnel in most small businesses often makes it difficult to adequately segregate incompatible duties. Therefore, the services of other non-bookkeeping personnel, such as the receptionist or even the business owner, can sometimes be used in a limited capacity to provide some segregation. Also, a closer involvement in the day-to-day affairs by the small business owner and accountant often partially compensates for the lack of segregation of duties.

Restricted Access

Restricted access is a control category closely related to the segregation of duties. Not only should bookkeeping duties be segregated whenever possible, but physical access to valuable and moveable assets should be restricted to only authorized personnel.

For example, access to warehouses and other inventory should be restricted to only those people with responsibility for maintaining inventory. In almost all instances, salespersons should not have access to inventory locations. Also, inventory should not be shipped from the warehouse unless accompanied by appropriate shipping documents. In addition, unused checks and petty cash should be kept in a secure area such as a locked filing cabinet.

Document Controls

Since source documents initiate the recording of transactions, it is essential that adequate controls exist to ensure that the accounting system captures all source documents. Source document controls principally include using pre-numbering documents and accounting for the numerical sequence of those documents.

Common pre-numbered source documents include invoices, credit memos, sales receipts, checks, purchase orders, and vendor
credits

Processing Controls

Once documents are recorded in the accounting system, processing controls help ensure that the documents are processed accurately. Common processing controls include:

- Batch controls — Preparing batch control totals of key source document amounts to ensure the amounts are entered into the accounting system accurately. For example, the receptionist or person opening the mail runs an adding machine tape of total payments received from customers for the day. After the bookkeeper records the payments, the adding machine tape total is compared to the recorded payments to ensure all payments were accurately entered

- Source document matching — Compare information on the various source documents to ensure they match. For example, for vendor shipments, this control might include comparing quantities and part numbers on purchase orders and shipping documents with vendor invoices and comparing prices on purchase orders and price lists with vendor invoices. For customer shipments, this control might include comparing quantities and part numbers on sales orders and shipping documents with customer invoices and comparing prices on sales orders and price lists with customer invoices

- Clerical accuracy of documents — Checking the mathematical accuracy of financial data on key source documents, such as vendor invoices, customer invoices, and time sheets. For example, bookkeepers may recalculate the extended prices on invoices by multiplying the quantity by the unit price 
- 
- General ledger account checking — Checking to ensure that amounts on source documents (such as vendor invoices) are categorized with the appropriate general ledger accounts

Processing controls are designed to catch errors before they are posted to the general ledger.

Reconciliation Controls

Reconciliations consist of reconciling selected general ledger control accounts to subsidiary ledgers. A control account is an account in the general ledger with a corresponding subsidiary ledger. The subsidiary ledger provides more detail and supporting information of the control account. For example, accounts receivable and accounts payable are general ledger control accounts and the Accounts Receivable Aging and Accounts Payable Aging reports are the subsidiary ledgers for those accounts. In contrast to processing controls, reconciliation controls are designed to detect errors after transactions have been posted to the general
ledger.

Accountants commonly reconcile accounts receivable, property and equipment, and accounts payable control accounts to their respective subsidiary ledgers.

Bank accounts and credit card accounts are not controlled accounts, however, monthly bank and credit card statement reconciliations are also essential reconciliation controls over cash and credit card balances.

Summary

To perform to the best of their abilities and to receive increased responsibility, bookkeepers should have a good understanding of all the accounting processes and their purposes in the accounting system.

Getting an understanding of the "big picture” of the accounting system involves understanding how the various financial records interact within the accounting system. Key financial records include various source documents, summary journals, subsidiary ledgers, general ledgers, and financial statements. The accounting system starts with numerous source documents and continuous processes and groups these transactions to ultimately produce daily, weekly, monthly, quarterly, and annual financial reports.

Each accounting transaction falls into one of the accounting processes or cycles. Common accounting processes include sales, accounts receivable, and cash receipts; purchasing, accounts payable, and cash disbursements; payroll; and general ledger and financial statement reports. Although the general steps performed in each of these processes may appear similar on the surface, the specific procedures performed are generally quite different. There are also certain aspects of each process that are more vital than others,

Although bookkeepers may not have direct responsibility for internal accounting controls, a basic understanding of controls is helpful for understanding why accounting procedures are performed in a certain way. This knowledge can also help bookkeepers improve the company’s control environment when circumstances permit. The controls generally fall into one of the following

categories: segregation of duties, restricted access controls, document controls, processing controls, and reconciliation controls.
